var fortunes = [
    "Sim",
    "Não",
    "Talvez",
    "Eu não sei, tente de novo",
    "Quem sabe?",
    "Claro que não tá **LOKO(A)**",
    "Vai saber neh ?",
    "SIMMM, PODE TER CERTEZA ",
    "Com certeza",
    "Meu informante disse É **CLARO QUE SIM **",
    
    "Algum dia tem informo sobre isso, agora to ocupada",
    "Eu não sei, Pare de me incomodar, **RUM**",
    "Eu vi em || sei n em, tu parece ser em||",
    "Claro que sim tá **Pdp ?**",
    "Vai saber neh ?",
    "É biscoito, PODE TER CERTEZA ",
    "Claro q sim, alias sabia q a gente é da msm familia ? ",
    "Meu informante disse É **CLARO QUE não**",
    








    
    "Isso é um mistério",
    "Não posso te contar agora",
    "Meu informante disse que não",
    "Provavelmente",
    "Me pergunte mais tarde!",
    "Claro que não!",
    "Não conte comigo para isso",
    "Dúvido muito"
     
  ];

  exports.run = (bot, msg, params) => {

    if(!params[0]){
      return msg.channel.send(":x: " + "| Por favor insira uma pergunta!")
    }
    if (params[0]) msg.channel.send(fortunes[Math.floor(Math.random() * fortunes.length)]);
    else msg.channel.send(":x: " + "| Não foi possível ler sua pergunta! :(");

  };


  exports.help = {
    name : "8ball",
    description: "Te da resposta para suas perguntas!",
    usage: "8ball [pergunta]"
  }; 
