const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://media.giphy.com/media/dCLrYGTl75l7WFRJtC/giphy.gif',
  'https://pa1.narvii.com/6383/299704c8c05b6e79a30d2b98f5f4b6f13628293f_hq.gif',
  'http://31.media.tumblr.com/tumblr_m08irneWad1r9ns55o1_500.gif'
  
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para apertar as bochechas!');
}
/*
message.channel.send(`${message.author.username} ** acaba de apertar as bochecas de ** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle(':full_moon_with_face: | Bochechas')
        .setColor('#dc143c')
        .setDescription(`⇨ ${message.author} apertou as bochechas de ${user}`)
        .setImage(rand)
      .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
        
  await message.channel.send(embed);
}