
const Discord = require("discord.js")
 
exports.run = (bot, message, args) => {
  let user = message.mentions.users.first() || bot.users.cache.get(args[0])
    var membro = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!membro) return message.reply(' O Comando  não é assim, digite-o  assim: `B!ban <usuario> + <motivo>`')
    if (membro === message.member) return message.reply(` Desculpe, mas você não tem permissão para isso.`)
 
    var motivo = args.slice(1).join(" ");
    if (!motivo) return message.channel.send(`Motivo inválido.`)
    if (!message.member.hasPermission("BAN_MEMBERS")) return message.reply(` Desculpe, mas você não tem permissão para isso.`)
    if(!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send(' Desculpe, mas você não tem permissão para isso.')
    if(!message.guild.me.hasPermission("BAN_MEMBERS")) return message.channel.send(' Desculpe, mas você não tem permissão para isso.')
 
        message.channel.send(`**Para banir o  ${user} clique no emoji:**`).then(msg => {
        msg.react("👍")
 
        let filtro = (reaction, usuario) => reaction.emoji.name === "👍" && usuario.id === message.author.id;
        let coletor = msg.createReactionCollector(filtro, {max: 1})
 
        coletor.on("collect", cp => {
            cp.remove(message.author.id); {
                let embed = new Discord.MessageEmbed()
                .setTitle('🚨 | BANIMENTO')
                .setColor('#ff210e')
                .setTimestamp()
                .setThumbnail('https://media.discordapp.net/attachments/780766464269221899/792747775350669312/f5f43be48e7804a8265947d8dd64e430.png')
                .addFields(
                    {
                    name: "**:bookmark_tabs: ・  Informações do Ban:**",
                    value: `**・ Moderador:**\n ${message.author.username}\n **・ Usuário Banido:**\n ${membro} \n **・ Motivo:**\n ${motivo} \n`
                  }
                )
                message.channel.send(embed);
            }
            membro.ban();
        })
    })
}