 client.on("message", async message => {
    let prefix = res ? res.prefix : config.prefix;
    if (message.author.bot) return;
    if (message.channel.type === "dm") return;
    if (message.mentions.has(client.user)) { 
        message.channel.send(`<a:Rosa_seta_pg:754374503001358467> Olá, ${message.author}! Meu prefixo atual é \`${prefix}\` para ver meus comandos use \`${prefix}ajuda\``);
    }
    if(message.content.startsWith(`<@!${client.user.id}>`) || message.content.startsWith(`<@${client.user.id}>`)){
      return message.channel.send(`<a:Rosa_seta_pg:754374503001358467> Olá, ${message.author}! Meu prefixo atual é \`${prefix}\` para ver meus comandos use \`${prefix}ajuda\``)}
      var args = message.content.substring(prefix.length).split(" ");
       if (!message.content.startsWith(prefix)) return;

