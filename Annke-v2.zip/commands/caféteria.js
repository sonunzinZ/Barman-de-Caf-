const Discord = require('discord.js'); // puxando a livraria 'discord.js'
const config = require('../config.json')

exports.run = (client, message, args) => { // setando a base
// avisando sobre a embed de ajuda na DM

     const embed = new Discord.MessageEmbed()
        .setTitle('Barman de café `1.0.4A`')        
        
        .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
       .setColor("#fa9d81")
       .setImage('https://media.discordapp.net/attachments/765551001331171342/773873360236969994/unknown.png')
       .setDescription('Seja muito bem vindo(a) ao meu cardapio! \n\n\n🍵 `Bebidas` \n🍡 `Doces` \n🌮 `Salgados`\n🍰 `Bolos` \n:back: Inicio')
        message.channel.send({embed}).then(msg => { // evento para reagir a mensagem
            msg.react('🍵').then(r => { // mod
            msg.react('🍡').then(r => { // uteis
            msg.react('🌮').then(r => { //entretenimento
            msg.react('🍰').then(r => { // bot
            msg.react('🔙').then(r => { // inicio
            })
        })
      })
    })
 })
        // filtros de cada reação, para configurar a informação do autor
        const BotFilter = (reaction, user) => reaction.emoji.name === '🍰' && user.id === message.author.id;
        const UtilidadesFilter = (reaction, user) => reaction.emoji.name === '🍡' && user.id === message.author.id;
        const ModeraçãoFilter = (reaction, user) => reaction.emoji.name === '🍵' && user.id === message.author.id;
        const EntretenimentoFilter = (reaction, user) => reaction.emoji.name === '🌮' && user.id === message.author.id;
        const BackFilter = (reaction, user) => reaction.emoji.name === '🔙' && user.id === message.author.id;
        // coletores de cada reação, para ver confirmar tal membro 
        const Bots = msg.createReactionCollector(BotFilter);
        const Utilidades = msg.createReactionCollector(UtilidadesFilter);
        const Moderação = msg.createReactionCollector(ModeraçãoFilter);
        const Entretenimento = msg.createReactionCollector(EntretenimentoFilter);
        const Back = msg.createReactionCollector(BackFilter);

        Bots.on('collect', r2 => {
         r2.users.remove(message.author.id)
         const embed = new Discord.MessageEmbed()
          .setTitle('🍰 BOLOS')
          
          .addField(`\`${config.prefix}convite\``, `O link de convite para adicionar o bot.
`)
          .addField(`\`${config.prefix}Annke\``, `Saber um pouco sobre.
`)         
 .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
          .setColor("#fa9d81")
          msg.edit(embed)
        }) 

        Utilidades.on('collect', r2 => { // criando um evento, caso o membro clique nessa reação, e todos são iguais!
            r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
                .setTitle("🍡 Doces")
                
                .addField(`\`${config.prefix}uptime\``, `Veja a quanto tempo o bot se encontra online.`)
                .addField(`\`${config.prefix}addrole\``,`Adiciona uma função a um usuário.`)
                .addField(`\`${config.prefix}removerole\``,`Remove uma função para um usuário. `)
                .addField(`\`${config.prefix}report\``,`
Permite que os usuários relatem outro membro. Todos os relatórios serão armazenados em um canal denominado 'relatórios'. O bot deve ter permissão para criar canais.

`)
                .addField(`\`${config.prefix}warnings\``,`Exibe todos os avisos anteriores de um usuário.`)
                .addField(`\`${config.prefix}clearwarnings\``,`Limpa todos os avisos de um usuário.`)

                .addField(`\`${config.prefix}avatar\``, `Amplie a foto de algum user.`)
                .addField(`\`${config.prefix}sugestão\``, `Envie uma sugestão.`)
                .addField(`\`${config.prefix}ping\``, ` Obtém o ping do servidor e do bot.`)
                .addField(`\`${config.prefix}level\``,`Obtenha seu nível atual, classificação e progresso de nível.`)
                .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
                .setColor("#fa9d81")

            msg.edit(embed);
        })
 
        Moderação.on('collect', r2 => {
            r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
                .setTitle("🍵 BEBIDAS")
               
                 .addField(`\`${config.prefix}cafe\``, `Tome um cafézinho normal. `)
                .addField(`\`${config.prefix}café com leite\``, `Tome um cafézinho com leite.`)
                .addField(`\`${config.prefix}cappuccino\``, `Bebida italiana preparada com café expresso e leite.`)
                .addField(`\`${config.prefix}coquinha gelada\``, `Tome uma coquinha gelada pra refrescar.`)
                .addField(`\`${config.prefix}fanta laranja\``, `Tome uma fanta de laranja pra relaxar.`)
                .addField(`\`${config.prefix}fanta uva\``, `Tome uma fanta de uva pra relaxar.`)
                .addField(`\`${config.prefix}guaraná\``, `Tome aquele guaraná geladinho.`)
                .setColor("#fa9d81")
            .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
            msg.edit(embed);
        })
 
        Entretenimento.on('collect', r2 => {
           r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
                .setTitle("🌮 SALGADOS")
                .addField(`\`${config.prefix}coxinha\``, `Qual tal comer um bela coxinha.`)
                .addField(`\`${config.prefix}pastel e caldo de cana\``, `Pastel com caldo de cana gostosin.`)
                 .addField(`\`${config.prefix}pastel de forno\``, `Pastel assado gostosin.`)
                .setColor("#fa9d81")
                  .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
            msg.edit(embed);
        })

        Back.on('collect', r2 => {
           r2.users.remove(message.author.id) 
            const embed = new Discord.MessageEmbed()
          .setTitle('Barman de café `1.0.4A`')  
           .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))

        .setColor("#fa9d81")
        .setImage('https://media.discordapp.net/attachments/765551001331171342/773873360236969994/unknown.png')
        .setDescription('Seja muito bem vindo(a) ao meu cardapio! \n\n\n☕️ `Bebidas` \n:dango: `Doces` \n:taco: `Salgados`\n:cake: `Bolos` \n:back: Inicio')
                        
           msg.edit(embed);  
        });
    });
}
exports.help = { // setando o nome do arquivo, seguido do prefix
    name: "help",
    aliases: ['ajuda', 'comandos']
}
          