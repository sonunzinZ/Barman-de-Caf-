
 
const Discord = require('discord.js');

exports.run = (client, message, args) =>{
    var dogs = [
        'https://media.giphy.com/media/Xqlsn2kLPBquI/giphy.gif',
        'https://media.giphy.com/media/ROF8OQvDmxytW/giphy.gif',
        'https://media.giphy.com/media/mvRwcoCJ9kGTS/giphy.gif',
        'https://media.giphy.com/media/oS4LjGIpwuE1O/giphy.gif',
        'https://media.giphy.com/media/dYo5SsWTzHu8w/giphy.gif',
        'https://media.giphy.com/media/shVJpcnY5MZVK/giphy.gif',
        'https://media.giphy.com/media/jj8DoqSYVJhPW/giphy.gif',

    ];

    const embed = new Discord.MessageEmbed()
        .setColor("RANDOM")
        .setTitle(":sob: | Chorar")
        .setTimestamp()

        .setDescription(`${message.author} **está chorando ;-;**`)
        .setImage(dogs[Math.floor(Math.random()*dogs.length)]);

    return message.channel.send(embed);    
}