const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
    'https://media.discordapp.net/attachments/780766458405191720/795241535380783114/5dd494651cdbe35db6debaff1eec9c5e01f9fd65_hq.gif', 
   
];



var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply(' Lembre-se de mencionar um usuário válido para escrever no death note');
}
/*
message.channel.send(`${message.author.username} **acaba de dar um cookie para** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle(':skull_crossbones: | Death Note')
        .setColor('RED')
        .setDescription(`${message.author} **Acaba de escrever o nome de ${user} no Death Note**`)
        .setImage(rand)
        .setTimestamp()
        
        
        
  await message.channel.send(embed);
}