
const Discord = require('discord.js')//puxando o bagulho do discord

module.exports.run = async (bot, message, args) => {//exportando o comando como denunciar
  message.delete()  
  let msg = args.slice(1).join(' ')
  if(!msg) {
    return message.channel.send("Denuncie alguém")
  }
  let embed = new Discord.MessageEmbed()
    .setColor("RED")
    .setFooter("Denúncia feita por: "+message.author.username, message.author.displayAvatarURL({dynamic: "gif", format: "png", size: 32}))
    .setTitle(":closed_book: | Nova denúncia")
    .setDescription(msg)
    
  bot.channels.cache.get("781450565321490463").send(embed)
  message.channel.send(":white_check_mark: | Denúncia feita com sucesso <@"+message.author.id+"> !")
}
