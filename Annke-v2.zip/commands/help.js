const Discord = require('discord.js'); // puxando a livraria 'discord.js'
const config = require('../config.json')

exports.run = (client, message, args) => { // setando a base
// avisando sobre a embed de ajuda na DM

     const embed = new Discord.MessageEmbed()
        
       .setAuthor('Barman de Café', 'https://images-ext-1.discordapp.net/external/Bug5Ir-NROQDJ4Pe7R9b2RaylYFvSUugxXxDoM2CxBg/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/766084351162056745/e020cd60ab5bea5505835a03872d76a8.webp?width=435&height=435')
       .setImage('https://media.discordapp.net/attachments/780766464269221899/793439627959861258/unknown.png')
     .setTitle('|| ||  :bookmark_tabs: - Menu de ajuda')
   .setThumbnail('https://media.discordapp.net/attachments/781520621535232030/782975076705632276/742240408658247791.png')
   .setColor('#b731ff')
    .setDescription(` Olá **${message.author.username}**, meu prefixo neste servidor **\`\`${message.guild.name}\`\`** é: **${config.prefix}** . Este é minha **central de comandos**, abaixo você poderá ver todos meus comandos, **separados por categorias**.`)
   
    
    
    .addField("** || || [ :hammer_pick: - Moderação ]**", " \n ** ``listban`` ``caifora`` ``ban`` ``caifora`` ``vaza`` ``unban`` ``kick`` ``mute`` ``unmute`` ``slowmode``**")
   
    .addField("** || || [ :dizzy: -  Úteis ]**", "**``setrole`` ``remrole``  ``anuncio`` ``enquete`` ``sorteio``  ``warn`` ``warnings`` ``reset-warn`` ``embed`` ``ideia`` ``lock`` ``unlock``  ``criar_canal`` ``clear`` ** ** ``setsugestão`` ``sugestão``**")
    
   
    
    

   .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))


    message.channel.send({embed}).then(msg => { // evento para reagir a mensagem
            msg.react('💜').then(r => { // bot
            msg.react('🔙').then(r => { // inicio
    })
 })
        // filtros de cada reação, para configurar a informação do autor
        const BotFilter = (reaction, user) => reaction.emoji.name === '💜' && user.id === message.author.id;
        
        const BackFilter = (reaction, user) => reaction.emoji.name === '🔙' && user.id === message.author.id;
        // coletores de cada reação, para ver confirmar tal membro 
        const Bots = msg.createReactionCollector(BotFilter);
       
        const Back = msg.createReactionCollector(BackFilter);

        Bots.on('collect', r2 => {
         r2.users.remove(message.author.id)
         const embed = new Discord.MessageEmbed()
               .setTitle(' || || [ :crescent_moon: - Outros ]')
              .setColor('#b731ff')
              .setAuthor('Barman de Café', 'https://images-ext-1.discordapp.net/external/Bug5Ir-NROQDJ4Pe7R9b2RaylYFvSUugxXxDoM2CxBg/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/766084351162056745/e020cd60ab5bea5505835a03872d76a8.webp?width=435&height=435')
             .setThumbnail('https://media.discordapp.net/attachments/781520621535232030/782975076705632276/742240408658247791.png')
             .setImage('https://media.discordapp.net/attachments/780766464269221899/793439627959861258/unknown.png')
             .addField("** [ :rocket: -  Entrentenimento ]**", "**``stronks`` ``biscoito`` ``ship`` ``laranjo`` ``kiss`` ``avatar`` ``wanted`` ``slap`` ``apertar `` ``hug`` ``cocegas `` ``coinflip`` ``ship``   ``meme`` ``anime``  ``dog`` ``dados`` ``8ball`` ``jokempo`` ``forca`` ``hack`` ``clyde`` ``phcomment`` ``kill`` ``chorar``**")
    
    
    
     .addField("** || || [ :warning: - Info ]**", "**``botinfo`` ``serverinfo`` ``userinfo`` ``uptime`` ``ping`` ``convites``**")

           .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
          msg.edit(embed)
        }) 

           Back.on('collect', r2 => {
           r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
       .setAuthor('Barman de Café', 'https://images-ext-1.discordapp.net/external/Bug5Ir-NROQDJ4Pe7R9b2RaylYFvSUugxXxDoM2CxBg/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/766084351162056745/e020cd60ab5bea5505835a03872d76a8.webp?width=435&height=435')

   .setTitle('|| || :bookmark_tabs: - Menu de ajuda ')
   .setThumbnail('https://media.discordapp.net/attachments/781520621535232030/782975076705632276/742240408658247791.png')
   .setImage('https://media.discordapp.net/attachments/780766464269221899/793439627959861258/unknown.png')
   .setColor('#b731ff')
    .setDescription(` Olá **${message.author.username}**, meu prefixo neste servidor **\`\`${message.guild.name}\`\`** é: **${config.prefix}** . Este é minha **central de comandos**, abaixo você poderá ver todos meus comandos, **separados por categorias**.`)
   
    
    .addField("** || || [ :hammer_pick: - Moderação ]**", " \n ** ``listban`` ``caifora`` ``ban`` ``caifora`` ``vaza`` ``unban`` ``kick`` ``mute`` ``unmute`` ``slowmode``**")
   
    .addField("** || || [ :dizzy: - Úteis ]**", "**``setrole`` ``remrole``  ``anuncio`` ``enquete`` ``sorteio``  ``warn`` ``warnings`` ``reset-warn`` ``embed`` ``ideia`` ``lock`` ``unlock``  ``criar_canal`` ``clear`` ** ** ``setsugestão`` ``sugestão``**")
    
   

   .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))


           msg.edit(embed);  
        });
    });
}
exports.help = { // setando o nome do arquivo, seguido do prefix
    name: "help",
    aliases: ['ajuda', 'comandos']
}