const Discord = require('discord.js'); // puxando a livraria 'discord.js'
const config = require('../config.json')

exports.run = (client, message, args) => { // setando a base
// avisando sobre a embed de ajuda na DM

     const embed = new Discord.MessageEmbed()
         .setAuthor('Barman de Café -2.0.0A ', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')
        
        
       .setImage(`https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png`)
       
        .setColor("#4eeb72")
       .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
        .setDescription(`:blue_book: **| Menu De Ajuda** \n\n Olá **${message.author.username}**, meu prefixo neste servidor é: **${config.prefix}**. Esta é minha **central de ajuda**, abaixo você poderá ver minhas categorias.\n \n1️⃣ | Moderação  \n2️⃣ | Utilidades  \n3️⃣ | Entretenimento \n4️⃣ | Configurações \n5️⃣ | Diversão \n6️⃣ | Info`)
        
    message.channel.send({embed}).then(msg => { // evento para reagir a mensagem
            msg.react('🔙').then(r => { // inicio
            msg.react('1️⃣').then(r => { // mod
            msg.react('2️⃣').then(r => { // uteis
            msg.react('3️⃣').then(r => { //entretenimento
            msg.react('4️⃣').then(r => { // bots
            msg.react('5️⃣').then(r => { // diversão
            msg.react('6️⃣').then(r => { // info
            
            })
            })
        })
        })
      })
    })
 })
        // filtros de cada reação, para configurar a informação do autor
        const BotFilter = (reaction, user) => reaction.emoji.name === '4️⃣' && user.id === message.author.id;
        const DiversãoFilter = (reaction, user) => reaction.emoji.name === '5️⃣' && user.id === message.author.id;
        const InfoFilter = (reaction, user) => reaction.emoji.name === '6️⃣' && user.id === message.author.id;
        const UtilidadesFilter = (reaction, user) => reaction.emoji.name === '2️⃣' && user.id === message.author.id;
        const ModeraçãoFilter = (reaction, user) => reaction.emoji.name === '1️⃣' && user.id === message.author.id;
        const EntretenimentoFilter = (reaction, user) => reaction.emoji.name === '3️⃣' && user.id === message.author.id;
        const BackFilter = (reaction, user) => reaction.emoji.name === '🔙' && user.id === message.author.id;
        // coletores de cada reação, para ver confirmar tal membro 
        const Bots = msg.createReactionCollector(BotFilter);
       const Diversão = msg.createReactionCollector
       (DiversãoFilter);
        const Info = msg.createReactionCollector
       (InfoFilter);
        const Utilidades = msg.createReactionCollector(UtilidadesFilter);
        const Moderação = msg.createReactionCollector(ModeraçãoFilter);
        const Entretenimento = msg.createReactionCollector(EntretenimentoFilter);
        const Back = msg.createReactionCollector(BackFilter);

        Bots.on('collect', r2 => {
        r2.users.remove(message.author.id) 
         const embed = new Discord.MessageEmbed()
           .setAuthor('Barman de Café -2.0.0A', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')
         
          .setTitle('4️⃣ | Configurações  \n \n:gear: | Comandos de Configuração:')
              
              .setDescription('⇨ B!warn <usuario> \n⇨ B!warnings - mostra o total de avisos \n⇨ B!reset-warn - reseta os avisos do usuario \n⇨ B!mute <usuario> \n⇨ B!unmute <usuario> \n⇨ B!embed <mensagem>  \n⇨ B!say <mensagem> \n⇨ B!ideia <sua ideia>')
              
          
          .setColor("#4eeb72")
          
          .setImage(`https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png`)
         .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
          msg.edit(embed)
        }) 
Diversão.on('collect', r2 => {
       r2.users.remove(message.author.id)  
         const embed = new Discord.MessageEmbed()
           .setAuthor('Barman de Café -2.0.0A', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')
         
          .setTitle('5️⃣ | Diversão \n \n:comet: |  Comandos de Diversão: ')
             .setDescription('⇨ B!apertar <usuario> \n⇨ B!slap <usuario> \n⇨ B!hug <usuario> \n⇨ B!kiss <usuario> \n⇨ B!cocegas <usuario> \n⇨ B!biscoito <usuario> \n⇨ B!coinflip - tire cara ou coroa \n⇨ B!ship <usuario 1>  <usuario 2> \n⇨ B!laranjo <texto>     ')
              
               
               .setColor("#4eeb72")
               .setImage(`https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png`)
          .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
          msg.edit(embed)
        }) 

Info.on('collect', r2 => {
         r2.users.remove(message.author.id)
         const embed = new Discord.MessageEmbed()
         .setAuthor('Barman de Café -2.0.0A', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')


             .setTitle('6️⃣ | Info \n \n :pushpin: | Comandos de info:')
               .setDescription('⇨ B!botinfo - info do bot \n⇨ B!serverinfo - informações do servidor \n⇨ B!userinfo  <usuario> \n⇨ B!uptime - tempo em que o bot está online \n⇨ B!ping - obtém o ping do servidor e do bot \n⇨ B!convites - rank de convites  ')

               .setColor("#4eeb72")
               .setImage(`https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png`)
          .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
          msg.edit(embed)
        }) 



        Utilidades.on('collect', r2 => { // criando um evento, caso o membro clique nessa reação, e todos são iguais!
            r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
                 .setAuthor('Barman de Café -2.0.0A', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')
         
                .setTitle("2️⃣ | Utilidades \n \n :dizzy: | Comandos de Utilidades:")
                 .setDescription('⇨ B!addrole <usuario> <nome da tag>\n⇨ B!remrole <usuario> <nome da tag> \n⇨ B!clima <nome da cidade> \n⇨ B!avatar <usuario>\n⇨ B!setsugestão <#canal> \n⇨ B!sugestão <mensagem>\n⇨ B!criar_canal <text ou voice> \n⇨ B!enquete <motivo>\n⇨ B!sorteio <tempo> <#canal> <prêmio>')
                
               
               .setImage('https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png')       .setColor("#4eeb72")       
              
                .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
                

            msg.edit(embed);
        })
 
           Back.on('collect', r2 => {
           r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
         .setAuthor('Barman de Café -2.0.0A', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')
         
        
        
       .setImage(`https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png`)
       
        .setColor("#4eeb72")
        .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
        .setDescription(`:blue_book: **| Menu De Ajuda** \n\n Olá **${message.author.username}**, meu prefixo neste servidor é: **${config.prefix}**. Esta é minha **central de ajuda**, abaixo você poderá ver minhas categorias.\n \n1️⃣ | Moderação  \n2️⃣ | Utilidades  \n3️⃣ | Entretenimento \n4️⃣ | Configurações \n5️⃣ | Diversão \n6️⃣ | Info`)
        
          msg.edit(embed);  
        })
       
        
        
        
        Moderação.on('collect', r2 => {
            r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
                .setAuthor('Barman de Café -2.0.0A', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')
         
                .setTitle(':one: | Moderação \n \n :hammer_pick: | Comandos de Moderação: ')
                
                .setDescription('\n:diamonds:** | Comando principal**: B!antiraid \n \n⇨ B!ban <usuario> <motivo> \n⇨ B!unban <usuario> <motivo> \n⇨ B!caifora <usuario> <motivo> \n⇨ B!kick <usuario> <motivo> \n⇨ B!lock - tranca algum chat \n⇨ B!listban - lista de banimentos \n⇨ B!unlock - destranca o chat \n⇨ B!clear <quantidade> \n⇨ B!modo-lento <tempo> \n⇨ B!anuncio <canal>  ')
                
              
                .setColor("#4eeb72")
                
                .setImage(`https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png`)
               .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
            msg.edit(embed);
        })
 
        Entretenimento.on('collect', r2 => {
            r2.users.remove(message.author.id)
            const embed = new Discord.MessageEmbed()
                .setAuthor('Barman de Café -2.0.0A', 'https://media.discordapp.net/attachments/780766466454061056/781637831784792084/e020cd60ab5bea5505835a03872d76a8.png')

                .setTitle("3️⃣ | Entretenimento \n \n:rocket: | Comandos de Entretenimento: ")
                
                .setDescription(':diamonds:** | Comando principal:** B!create_meme \n \n⇨ B!memes - envia alguns memes \n⇨ B!anime <anime> - informações do anime   \n⇨ B!dados - jogue dados \n⇨ B!8ball <pergunta>  \n⇨ B!forca - jogue forca \n⇨ B!jokempo - pedra, papel, tesoura \n⇨ B!dog - foto de um doguinho fofineo\n⇨ B!firstworld <texto> ')

                
                .setColor("#4eeb72")
                .setImage(`https://images-ext-2.discordapp.net/external/wDlVGIaw5fX1dtOpDC-rY_2WoRJ4lKJV0AMq2nRKWOw/https/media.discordapp.net/attachments/765551001331171347/778301471841189918/unknown.png`)          
               .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
            msg.edit(embed);
       
        });
       
    });
}
exports.help = { // setando o nome do arquivo, seguido do prefix
    name: "help",
    aliases: ['ajuda', 'comandos']
}