const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
    'https://media.giphy.com/media/BTV1vUcOWht2U/giphy.gif', 'https://media.giphy.com/media/yy1rPT45jdX1K/giphy.gif',
    'https://media.giphy.com/media/eLsxkwF5BRtlK/giphy.gif',
    'https://media.giphy.com/media/eLsxkwF5BRtlK/giphy.gif',
    'https://media.giphy.com/media/q0vzRkA3NNYVtvt8rn/giphy.gif',
];



var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply(' Lembre-se de mencionar um usuário válido para matar');
}
/*
message.channel.send(`${message.author.username} **acaba de dar um cookie para** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle(':dizzy_face: | KILL')
        .setColor('RED')
        .setDescription(`${message.author} **Acaba de Matar ${user}**`)
        .setImage(rand)
        .setTimestamp()
        
        
        
  await message.channel.send(embed);
}