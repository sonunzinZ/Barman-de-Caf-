const Discord = require('discord.js')
const c = require('../config.json')
exports.run = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(`${message.author}, você não possui permissão para executar esse comando.`).then(msg=> msg.delete(8000))
    
    let mensg = args.join(' ')
    if(!mensg) {
        message.channel.send(`${message.author}, digite uma mensagem para inserir.`)
    return undefined;
    }

        const embed = new Discord.MessageEmbed()
    .setDescription(`${mensg}`)
    .setTitle('|| || Leia abaixo :')
    
    .setImage('https://media.discordapp.net/attachments/786147635089768469/794187592399847425/unknown.png?width=435&height=435')
    .setColor("Black")
    .setTimestamp()
        message.channel.send(embed)
}

exports.help = {
    name: "embed",
    aliases: ['sendembed']
}