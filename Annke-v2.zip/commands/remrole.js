const { MessageEmbed } = require("discord.js");
const db = require('quick.db');

module.exports = {
    config: {
        name: "removerole",
        category: "moderation",
        aliases: ["rr"],
        description: "Removes role from the user",
        accessableby: "Administrator",
        usage: "[name | nickname | mention | ID] <role>",
    },
    run: async (bot, message, args) => {

        if (!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send("**Você não tem as permissões para remover a função dos usuários! - [MANAGE_ROLES]**");

        if (!message.guild.me.hasPermission("MANAGE_ROLES")) return message.channel.send("**Não tenho permissão para remover funções dos usuários! - [MANAGE_ROLES]**");
        
        if (!args[0]) return message.channel.send("**Insira um usuário!**")

        let rMember = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.guild.members.cache.find(r => r.user.username.toLowerCase() === args[0].toLocaleLowerCase()) || message.guild.members.cache.find(ro => ro.displayName.toLowerCase() === args[0].toLocaleLowerCase());
        if (!rMember) return message.channel.send("**Não foi possível encontrar esse usuário**");

        let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]) || message.guild.roles.cache.find(rp => rp.name.toLowerCase() === args.slice(1).join(' ').toLocaleLowerCase());
        if (!args[1]) return message.channel.send("**Por favor, insira uma função!**");

        if (!role) return message.channel.send("**Não consegui encontrar esse papel**");

        if (rMember.roles.highest.comparePositionTo(message.guild.me.roles.highest) >= 0) return message.channel.send('**Não é possível remover a função deste usuário! - [Higher Than Me In Role Hierachy]**')
        if (message.guild.me.roles.highest.comparePositionTo(role) < 0) return message.channel.send('**A função é atualmente maior do que eu, portanto, não posso removê-la do usuário!**')
        if (role.managed) return message.channel.send("**:x: | Não é possível remover essa função deste usuário!**")

        if (!rMember.roles.cache.has(role.id)) return message.channel.send("**O usuário não tem o papel!**")
        if (rMember.roles.cache.has(role.id)) await (rMember.roles.remove(role.id));

        const sembed = new MessageEmbed()
            .setColor("#395a94")
            .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))
            .setAuthor(message.guild.name, message.guild.iconURL())
            .setDescription(`**:ballot_box_with_check: | A função foi removida de ${rMember.user.username}**`)
        message.channel.send(sembed);

        let channel = db.fetch(`modlog_${message.guild.id}`)
        if (!channel) return;

        const embed = new MessageEmbed()
            .setAuthor(`${message.guild.name} Modlogs`, message.guild.iconURL())
            .setColor("#ff0000")
            .setThumbnail(rMember.user.displayAvatarURL({ dynamic: true }))
            .setFooter(message.guild.name, message.guild.iconURL())
            .addField("**Moderation**", "removerole")
            .addField("**Removed Role from**", rMember.user.username)
            .addField("**Role Added**", role.name)
            .addField("**Removed By**", message.author.username)
            .addField("**Date**", message.createdAt.toLocaleString())
            .setTimestamp();

        var sChannel = message.guild.channels.cache.get(channel)
        if (!sChannel) return;
        sChannel.send(embed)
    }
}