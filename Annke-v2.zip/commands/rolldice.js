const Discord = require('discord.js');

exports.run = (client, message, args) =>{
    var dice = [1, 2, 3, 4, 5, 6];

    const embed = new Discord.MessageEmbed()
        .setColor("#d11114")
        .setImage("https://media.discordapp.net/attachments/769123922096029697/769604032758939669/barrinha02_1.gif")
        .addField(":first_place: | Primeiro dado", dice[Math.floor(Math.random()*dice.length)], true)
        .addField(":second_place: | Segundo dado", dice[Math.floor(Math.random()*dice.length)], true)
        .setTimestamp();

    return message.channel.send(embed);    
}
