
 
const Discord = require("discord.js");

exports.run = (client, message, args) => {


    let embed = new Discord.MessageEmbed()

    .setColor('#60dd85')
    .setDescription(":arrow_down: **[Baixe a imagem](" + message.guild.iconURL() + ")**")
    .setImage(message.guild.iconURL())
    .setColor('#60dd85')
    .setFooter(`${message.guild.name}`)

    message.channel.send(embed)

}

exports.help = {
    name: 'servericon',
    aliases: ['iconserver']

}