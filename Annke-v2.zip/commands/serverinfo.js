
const Discord = require('discord.js');

exports.run = (bot,message,args) => {
    const guild = message.guild;
    
    let createdAt = String(guild.createdAt);
    const description = guild.description;
    const banner = guild.banner;
    const id = guild.id;
    const membersCount = guild.memberCount;
    const ownerID = guild.ownerID;
    const name = guild.name;
    const region = guild.region;
    const verified = guild.verified;

    createdAt = createdAt.split('.')[0]

    const response = new Discord.MessageEmbed()
        .setColor("GREEN")
       
        .setTitle("  ❪ :open_file_folder: | Informações de Servidor:❫")
         .setThumbnail(message.guild.iconURL())
       

        .setAuthor('Barman de Café -2.0.0A', 'https://images-ext-1.discordapp.net/external/Bug5Ir-NROQDJ4Pe7R9b2RaylYFvSUugxXxDoM2CxBg/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/766084351162056745/e020cd60ab5bea5505835a03872d76a8.webp?width=395&height=395')
        .addFields(
            { name: ':envelope: | Nome:', value: name },
            { name: "\ || || :crown: | Dono:", value: `<@${ownerID}>` },
            { name: "\‍ :busts_in_silhouette: | Quantia de membros:", value: membersCount },
           
            { name: '\ :map: | Região:', value: region },
            { name: "\ :mag: | ID do Servidor (Para desenvolvedores):", value: id },
            { name: "\ :date: | Criado em:", value: createdAt },
        )
        		 .setFooter(`Comando utilizado por: ${message.author.username}`, message.author.displayAvatarURL({format: "png"}))

        

    message.channel.send(response);
}