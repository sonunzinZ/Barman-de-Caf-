
exports.run = (client, message, args) => {
    const setChannelID = message.content.split(' ');

    try{
        message.guild.channels.cache.get(setChannelID[1]).createInvite().then(invite =>
            message.channel.send(":white_check_mark: **| O convite do canal foi criado:** \n" + invite.url)
        );
    }

    catch(error){
        console.error(`:x: **|** Não consegui criar o convite para o canal: ${error}`);
        message.channel.send(`:no_entry_sign: **➤ Você deve colar um ID de canal correto.**`);
    }
}
