
const Discord = require('discord.js');

exports.run = (bot,message,args) => {
    const guild = message.guild;
    
    let createdAt = String(guild.createdAt);
    const description = guild.description;
    const banner = guild.banner;
    const id = guild.id;
    const membersCount = guild.memberCount;
    const ownerID = guild.ownerID;
    const name = guild.name;
    const region = guild.region;
    const verified = guild.verified;

    createdAt = createdAt.split('.')[0]

    const response = new Discord.MessageEmbed()
        .setColor("#00cfc1")
       
        .setTitle(" 📂 | Informações sobre o servidor")
         .setThumbnail(message.guild.iconURL())
        
        .setAuthor('Barman de Café -1.0.9A', 'https://images-ext-1.discordapp.net/external/Bug5Ir-NROQDJ4Pe7R9b2RaylYFvSUugxXxDoM2CxBg/%3Fsize%3D2048/https/cdn.discordapp.com/avatars/766084351162056745/e020cd60ab5bea5505835a03872d76a8.webp?width=395&height=395')
        .addFields(
            { name: ':sunny: | Nome:', value: name },
            { name: "\\😎 | Dono:", value: `<@${ownerID}>` },
            { name: "\\‍:page_with_curl: | Quantia de membros:", value: membersCount },
            { name: "\\📌 | Descrição:", value: `${description ? description : 'Nenhuma'}` },
            { name: '\\🗺 | Região:', value: region },
            { name: "\\🕵️ | ID do Servidor (Para desenvolvedores):", value: id },
            { name: "\\⏰ | Criado em:", value: createdAt },
        )
        .setTimestamp();

    message.channel.send(response);
}