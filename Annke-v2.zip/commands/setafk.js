
exports.run = (client, message, args) =>{
    const setStatus = message.content.split(' ');

    if(setStatus[1] === 'afk'){
        client.user.setAFK(true);
        message.channel.send("Seu status foi definido como afk!");
    }

    else if(setStatus[1] === 'notafk'){
        client.user.setAFK(false);
        message.channel.send(`Welcome back ${message.author}`);
    }

    else if(!setStatus[1] || setStatus[1] === undefined){
        message.channel.send("Você não escolheu afk ou notafk como status atual!!");
    }

    else{
        message.channel.send("Você não chafk ou notafk como status atual!");
    }

}