const Discord = require('discord.js');
const superagent = require('superagent');
const c = require('../config.json');

exports.run = async (client, message, args) => {

    if (!message.mentions.users.first()) return message.channel.send(`:no_entry: **・** Salve fofo(a)! **${message.author.username}**, você precisa mencionar um membro.`);
    if (message.mentions.users.first().id === "766084351162056745") return message.reply('por que deseja me bater? O que eu te fiz?!');
    if (message.mentions.users.first().id === "756241393482989758") return message.channel.reply(`não deixarei você bater em meu amigo!`);
    const { body } = await superagent
    .get("https://nekos.life/api/v2/img/slap");

    const embed = new Discord.MessageEmbed()
    .setColor("#60dd85")
    .setDescription(`**${message.author.username}** deu um tapa em **${message.mentions.users.first().username}**! :raised_hand:`)
    .setImage(body.url) 
    message.channel.send({embed})
}
exports.help = {
    name: 'slap',
    aliases: ['tapa']
}   