
 
const Discord = require('discord.js');

var sToggle = true;

exports.run = (client, message, args) =>{

    if(sToggle === true && !args[0]) {
            let randoMember = message.guild.members.cache.random().id;
            message.channel.send('<@' + randoMember + '>');
    }
    else if(sToggle === false && message.member.hasPermission('ADMINISTRATOR') && !args[0]) {
            let randoMember = message.guild.members.cache.random().id;
            message.channel.send('<@' + randoMember + '>');
    } 
        
    if(args[0] === "toggle" && message.member.hasPermission('ADMINISTRATOR')) {
    sToggle = !sToggle;
        if(sToggle === true) {
            message.channel.send("Habilitou `alguém` globalmente.")
        }
        else {
            message.channel.send("Desativou `alguém` globalmente. Comando bloqueado apenas para ADMINS.")
        }
    }
}