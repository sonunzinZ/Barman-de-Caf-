const Discord = require('discord.js');

exports.run = (client, message, args) =>{
    var dogs = [
        
        'https://media.discordapp.net/attachments/786147635089768469/794172658731581471/Foto-Shutterstock-Images-suco-laranja-perder-peso.png?width=653&height=435',
        'https://media.discordapp.net/attachments/786147635089768469/794172658731581471/Foto-Shutterstock-Images-suco-laranja-perder-peso.png?width=653&height=435',
        'https://media.discordapp.net/attachments/786147635089768469/794172722993168434/cardapio-sucos.png?width=435&height=435',
              ];

    const embed = new Discord.MessageEmbed()
        .setColor("#98fc4a")
        .setTitle(":tangerine: | Suco De Laranja")
        

        .setDescription(`**- Hey ${message.author}, Aqui está o seu suco de laranja, espero que ele esteja ao seu gosto;**`)
        .setImage(dogs[Math.floor(Math.random()*dogs.length)]);

    return message.channel.send(embed);    
}







