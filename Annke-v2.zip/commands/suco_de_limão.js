const Discord = require('discord.js');

exports.run = (client, message, args) =>{
    var dogs = [
        
        'https://media.discordapp.net/attachments/786147635089768469/794175387873443850/BelaCozinha-Instagram-CoraFoodConcept-20.png?width=435&height=435',
        'https://media.discordapp.net/attachments/786147635089768469/794174401067220992/503-limonada-suco-de-limC3A3o-sem-aC3A7C3BAcar.png',
        'https://media.discordapp.net/attachments/786147635089768469/794174182212501575/suco-de-limao.png?width=435&height=435',
        'https://media.discordapp.net/attachments/786147635089768469/794174597427757066/limonada_alcalina_caseira_7218_orig.png?width=653&height=435',   
         'https://media.discordapp.net/attachments/786147635089768469/794174906258292776/suco-de-limao-com-leite.png',    
         'https://media.discordapp.net/attachments/786147635089768469/794175004757590016/img_caipirinha_de_limao_com_vodka_e_leite_condensado_2926_600_square.png?width=435&height=435',  


              ];

    const embed = new Discord.MessageEmbed()
        .setColor("#ff9f5c")
        .setTitle(":lemon: | Suco De Limão")
        .setTimestamp()

        .setDescription(`**- Hey ${message.author}, Aqui está o seu suco de limão, espero que ele esteja ao seu gosto;**`)
        .setImage(dogs[Math.floor(Math.random()*dogs.length)]);

    return message.channel.send(embed);    
}



