
const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const { Color } = require("../../config.json");

module.exports = {
    name: "unban",
    aliases: null,
    category: "moderation",
    description: "Unban A Member!",
    usage: "Unban <Member ID>",
    accessableby: "everyone",
    run: async (client, message, args) => {

        //Start

        if (!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send(`Você não tem permissão para usar este comando!`);

        if (!args[0]) return message.channel.send(`Por favor, dê-me a ID de membro que você deseja desbanir!`);

        if (isNaN(args[0])) return message.channel.send(`Por favor, me dê uma identificação válida!`);

        if (args[0] === message.author.id) return message.channel.send(`Você já desbaniu o membro!`);

        if (args[0] === message.guild.owner.user.id) return message.channel.send(`Olá Proprietário do servidor o banimento já foi removido!`);

        if (args[0] === client.user.id) return message.channel.send(`Eu já desbani!`);

        let FetchBan = await message.guild.fetchBans();

        let Member;
        Member = FetchBan.find(b => b.user.username.toLowerCase() === args[0].toLocaleLowerCase()) || FetchBan.get(args[0]) || FetchBan.find(bm => bm.user.tag.toLowerCase() === args[0].toLocaleLowerCase());

        if (!Member) return message.channel.send("Forneça uma ID de membro válida ou o membro não será desbanido!");

        let Reason = args.slice(1).join(" ") || "Nenhum motivo fornecido!"

        try {
            message.guild.members.unban(Member.user.id, Reason)
        } catch(error) {
            return message.channel.send(`Não posso cancelar o banimento desse membro, talvez o membro não tenha sido banido ou algum erro!`)
        }

        let embed = new MessageEmbed()
        
        .setThumbnail('https://media.discordapp.net/attachments/780766464269221899/792747564856377364/60607b817ba7412ac83babae796c1d8c.png')
        .setColor('GREEN')
        .setDescription(`**:bookmark_tabs: ・ Informações de unban:**`)
        .setTitle(`:white_check_mark: | DESBANIDO`)
        .addField(`・ Moderador:`, `${message.author.tag} `)
       
        .addField(`・ Usuário Desbanido:`, `${Member.user.tag} `)
        .addField(`・ Motivo:`, `${Reason || "Nenhuma motivo inserido"}`)
       .setTimestamp()

        return message.channel.send(embed);

        //End

    }
};