const { MessageEmbed } = require("discord.js")
const db = require("quick.db")

module.exports = {
  name: "warn",
  category: "moderation",
  usage: "warn <@mention> <reason>",
  description: "Warn anyone who do not obey the rules",
  run: async (client, message, args) => {
    
    if(!message.member.hasPermission("ADMINISTRATOR")) {
      return message.channel.send(" :o: | Você deve ter permissões de administrador para usar este comando!")
    }
    
    const user = message.mentions.members.first()
    
    if(!user) {
      return message.channel.send("...| Por favor, mencione a pessoa a quem você deseja aplicar o aviso \n Ex: b!warn @mention <reaosn>")
    }
    
    if(message.mentions.users.first().bot) {
      return message.channel.send("Você não pode avisar os bots")
    }
    
    if(message.author.id === user.id) {
      return message.channel.send(":x: | Você não pode se avisar")
    }
    
    if(user.id === message.guild.owner.id) {
      return message.channel.send(":x: | Seu idiota, como você pode avisar o proprietário do servidor -_-")
    }
    
    const reason = args.slice(1).join(" ")
    
    if(!reason) {
      return message.channel.send(":o: | Forneça um motivo para avisar - \n Ex: b!warn @mention <reason>")
    }
    
    let warnings = db.get(`warnings_${message.guild.id}_${user.id}`)
    
    if(warnings === 3) {
      return message.channel.send(`${message.mentions.users.first().username} já atingiu seu limite com 3 avisos
`)
    }
    
    if(warnings === null) {
      db.set(`warnings_${message.guild.id}_${user.id}`, 1)
      user.send(`Você foi avisado em**${message.guild.name}** por ${reason}`)
      await message.channel.send(`Você avisou **${message.mentions.users.first().username}** for ${reason}`)
    } else if(warnings !== null) {
        db.add(`warnings_${message.guild.id}_${user.id}`, 1)
       user.send(`Você foi avisado em **${message.guild.name}** for ${reason}`)
      await message.channel.send(`Você avisou **${message.mentions.users.first().username}** por ${reason}`)
    }
    
  
  } 
}
